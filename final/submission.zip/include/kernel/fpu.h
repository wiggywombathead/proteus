#ifndef _FPU_H
#define _FPU_H

extern void fpu_enable(void);

#endif
