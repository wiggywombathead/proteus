var searchData=
[
  ['proc_5finit',['proc_init',['../proc_8h.html#afdd9e124a2e47f620d4165b86713c516',1,'proc.c']]]
];
