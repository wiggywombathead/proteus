var searchData=
[
  ['atag',['atag',['../structatag.html',1,'']]],
  ['atag_5fcmdline',['atag_cmdline',['../structatag__cmdline.html',1,'']]],
  ['atag_5fcore',['atag_core',['../structatag__core.html',1,'']]],
  ['atag_5finitrd2',['atag_initrd2',['../structatag__initrd2.html',1,'']]],
  ['atag_5fmem',['atag_mem',['../structatag__mem.html',1,'']]],
  ['atag_5framdisk',['atag_ramdisk',['../structatag__ramdisk.html',1,'']]],
  ['atag_5frevision',['atag_revision',['../structatag__revision.html',1,'']]],
  ['atag_5fserialnr',['atag_serialnr',['../structatag__serialnr.html',1,'']]],
  ['atag_5fvideolfb',['atag_videolfb',['../structatag__videolfb.html',1,'']]],
  ['atag_5fvideotext',['atag_videotext',['../structatag__videotext.html',1,'']]]
];
