var searchData=
[
  ['fb_5fallocate_5fres',['fb_allocate_res',['../structfb__allocate__res.html',1,'']]],
  ['fb_5fscreen_5fsize',['fb_screen_size',['../structfb__screen__size.html',1,'']]],
  ['framebuffer',['framebuffer',['../structframebuffer.html',1,'']]]
];
