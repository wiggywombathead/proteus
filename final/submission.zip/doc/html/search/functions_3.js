var searchData=
[
  ['get_5fconsole_5fheight',['get_console_height',['../gpu_8h.html#a7aa782e7276f4bddfd6781155491ca78',1,'gpu.c']]],
  ['get_5fconsole_5fwidth',['get_console_width',['../gpu_8h.html#aa17aaee5c99cb12998ccf11153a4a844',1,'gpu.c']]],
  ['get_5fscreen_5fheight',['get_screen_height',['../gpu_8h.html#ac75562efe7674f01e0ef391d05e7fc2c',1,'gpu.c']]],
  ['get_5fscreen_5fwidth',['get_screen_width',['../gpu_8h.html#abc4671f4cb70764d62e48f9a8814c86d',1,'gpu.c']]],
  ['get_5fserial_5fhi',['get_serial_hi',['../atag_8h.html#a820d373ce3349a6af20a5fb2a32a5808',1,'atag.c']]],
  ['get_5fserial_5flo',['get_serial_lo',['../atag_8h.html#add6923117c2848ad32ca92e02baa1925',1,'atag.c']]],
  ['get_5ftotal_5fmem',['get_total_mem',['../atag_8h.html#a05bd54aabaf16e64ce9a25e5abbfe7ca',1,'atag.c']]],
  ['gpu_5finit',['gpu_init',['../gpu_8h.html#a6f347ed95011f36930c0b26e322a31c9',1,'gpu.c']]],
  ['gpu_5fputc',['gpu_putc',['../gpu_8h.html#a5de928cae06770c0c3940afbfde7c501',1,'gpu.c']]]
];
