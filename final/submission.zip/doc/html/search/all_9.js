var searchData=
[
  ['mail_5fmessage',['mail_message',['../structmail__message.html',1,'']]],
  ['mail_5fstatus',['mail_status',['../structmail__status.html',1,'']]],
  ['mailbox_2eh',['mailbox.h',['../mailbox_8h.html',1,'']]],
  ['mailbox_5fread',['mailbox_read',['../mailbox_8h.html#acd808eb76927efb45d0c6bcef41b33bc',1,'mailbox.c']]],
  ['mailbox_5fsend',['mailbox_send',['../mailbox_8h.html#a65ec22fdcf778778ac31b6b1be1a3fb0',1,'mailbox.c']]],
  ['memory_2eh',['memory.h',['../memory_8h.html',1,'']]],
  ['memory_5finit',['memory_init',['../memory_8h.html#ac89b03af96bc930c9acab9789c7f46e6',1,'memory.c']]],
  ['mmio_5fread',['mmio_read',['../gpio_8h.html#a23ba7a7dfa9745868f8abf46c8aad2b5',1,'gpio.c']]],
  ['mmio_5fwrite',['mmio_write',['../gpio_8h.html#a412fadf8b67ea714acffa3cbe209203b',1,'gpio.c']]],
  ['mmu_2eh',['mmu.h',['../mmu_8h.html',1,'']]],
  ['mmu_5finit',['mmu_init',['../mmu_8h.html#ac139ab6eabfe7278410aaf6fe58ff04e',1,'mmu.c']]],
  ['mmu_5fpage',['mmu_page',['../mmu_8h.html#aef7df79db7d952b4f7c3b0315159ba1a',1,'mmu.c']]],
  ['mmu_5fsection',['mmu_section',['../mmu_8h.html#a77e35ae08c78414fae71f9a61202d7cb',1,'mmu.c']]],
  ['mutex',['mutex',['../structmutex.html',1,'']]]
];
