var searchData=
[
  ['cpu_5fstate',['cpu_state',['../structcpu__state.html',1,'']]]
];
