var searchData=
[
  ['free_5fpage',['free_page',['../memory_8h.html#a89cf15666552002c028800b10e3a324e',1,'memory.c']]]
];
