var searchData=
[
  ['value_5fbuffer',['value_buffer',['../unionvalue__buffer.html',1,'']]]
];
