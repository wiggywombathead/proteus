var searchData=
[
  ['clrs',['clrs',['../gpu_8h.html#a57b8e455c875d199c412acc183b74a0f',1,'gpu.c']]],
  ['cpu_5fstate',['cpu_state',['../structcpu__state.html',1,'']]],
  ['create_5fkthread',['create_kthread',['../proc_8h.html#a98636ee44c03ee1c080ef5182fef3cfd',1,'proc.c']]]
];
