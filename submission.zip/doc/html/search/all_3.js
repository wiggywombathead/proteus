var searchData=
[
  ['fb_5fallocate_5fres',['fb_allocate_res',['../structfb__allocate__res.html',1,'']]],
  ['fb_5fscreen_5fsize',['fb_screen_size',['../structfb__screen__size.html',1,'']]],
  ['fonts_2eh',['fonts.h',['../fonts_8h.html',1,'']]],
  ['framebuffer',['framebuffer',['../structframebuffer.html',1,'']]],
  ['framebuffer_2eh',['framebuffer.h',['../framebuffer_8h.html',1,'']]],
  ['free_5fpage',['free_page',['../memory_8h.html#a89cf15666552002c028800b10e3a324e',1,'memory.c']]]
];
