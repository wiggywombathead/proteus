var searchData=
[
  ['kfree',['kfree',['../memory_8h.html#acee1960bdb3a19cb495341ec725cafef',1,'memory.c']]],
  ['kmalloc',['kmalloc',['../memory_8h.html#a4c1b00f2d0f5cdb5499845540af2d0aa',1,'memory.c']]]
];
