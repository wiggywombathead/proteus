var searchData=
[
  ['sched_2eh',['sched.h',['../sched_8h.html',1,'']]],
  ['sched_5ffcfs',['sched_fcfs',['../sched_8h.html#a512adafd438b6efee2d06dc3d120c8cc',1,'sched.c']]],
  ['sched_5finit',['sched_init',['../sched_8h.html#ac76f0bd4fbafc057a2f780869968e3ed',1,'sched.c']]],
  ['sched_5fround_5frobin',['sched_round_robin',['../sched_8h.html#a99bb68e68f6b614ba9e1bd9a1f4e7a09',1,'sched.c']]],
  ['send_5fmessages',['send_messages',['../mailbox_8h.html#ad4397af6bd98de7d3af372dece5cf21a',1,'mailbox.c']]],
  ['shm_2eh',['shm.h',['../shm_8h.html',1,'']]],
  ['shm_5fsection',['shm_section',['../structshm__section.html',1,'']]],
  ['spin_5finit',['spin_init',['../spinlock_8h.html#ac9185f7485d90c165e2665ba5b411713',1,'proc.c']]],
  ['spin_5flock',['spin_lock',['../spinlock_8h.html#a3d606fd0c679b3a7dbb9e767bac2f468',1,'proc.c']]],
  ['spin_5funlock',['spin_unlock',['../spinlock_8h.html#a718fd63b7a37c8d32404066d688abe7f',1,'proc.c']]],
  ['spinlock_2eh',['spinlock.h',['../spinlock_8h.html',1,'']]],
  ['stdio_2eh',['stdio.h',['../stdio_8h.html',1,'']]],
  ['stdlib_2eh',['stdlib.h',['../stdlib_8h.html',1,'']]],
  ['string_2eh',['string.h',['../string_8h.html',1,'']]],
  ['sys_5ftimer',['sys_timer',['../structsys__timer.html',1,'']]]
];
