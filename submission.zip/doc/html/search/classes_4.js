var searchData=
[
  ['heap_5fsegment',['heap_segment',['../structheap__segment.html',1,'']]]
];
