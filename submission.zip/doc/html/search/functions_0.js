var searchData=
[
  ['act_5fblink',['act_blink',['../gpio_8h.html#a3f8d361fc124e0ce28c55283c919f45a',1,'gpio.c']]],
  ['act_5finit',['act_init',['../gpio_8h.html#a821a8d3883ed7877d4d1b63e5ca7340c',1,'gpio.c']]],
  ['act_5foff',['act_off',['../gpio_8h.html#a3ff62e4f6da132eba0e82f3024f44945',1,'gpio.c']]],
  ['act_5fon',['act_on',['../gpio_8h.html#a62746ed92e74a9073a526e924e03e6d2',1,'gpio.c']]],
  ['alloc_5fpage',['alloc_page',['../memory_8h.html#aa8d5f3f7f21f53fe7ffed7c329915441',1,'memory.c']]]
];
